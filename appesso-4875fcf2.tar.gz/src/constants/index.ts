export const POSTS_PER_PAGE = 3;
export const ACTIVITIES_PER_PAGE = 5;
export const DISCOVER_PROFILES_PER_PAGE = 4;
export const PROFILE_QUERY_STALE_TIME = 60000 * 10;
export const NO_PREV_DATA_LOADED = 'no_previous_data_loaded';
