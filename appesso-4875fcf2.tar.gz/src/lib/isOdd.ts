export const isOdd = (n: number) => n % 2 === 1;
