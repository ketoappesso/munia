import { GenericLoading } from '@/components/GenericLoading';

export default function Loading() {
  return <GenericLoading />;
}
