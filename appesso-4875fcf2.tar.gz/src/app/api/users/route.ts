export { GET } from './GET';
