export default function Page() {
  return <h1>Privacy Policy</h1>;
}
