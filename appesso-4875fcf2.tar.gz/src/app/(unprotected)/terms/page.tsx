export default function Page() {
  return <h1>Terms</h1>;
}
